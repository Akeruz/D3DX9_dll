|---------------------------------------------------|
| Package assembled by http://www.ThreeLights.de    |
|---------------------------------------------------|
|                                                   |
| This archive contains a modified version of the   |
| DirectX redistributable package which will update |
| your D3DX9_XX.dll files. The package has been     |
| assembled according to Microsoft's license        |
| agreements. You may find a copy of the original   |
| license agreement in the folder "License".        |
|                                                   |
| I know; the D3DX9_XX.dll thingy looks like a big  |
| mess to many people. But, each new D3DX version   |
| provides us with...                               |
|  - Bug Fixes                                      |
|  - Increased Compatibility                        |
|  - New Technology (ATLAS, PRT, ...)               |
|  - Security Fixes                                 |
|  - Speed Improvements                             |
| So, you should appreciate each update because it  |
| enables us developers to create faster and cooler |
| applications for you!                             |
|                                                   |
| WARNING:                                          |
| Installing the software included in this package  |
| may change system settings. Be aware, that you    |
| use this software at your own risk. If you are    |
| unsure whether you should or should not install   |
| this software, please ask am IT professional      |
| first.                                            |
|                                                   |
| This update adds the following files to an        |
| EXISTING DirectX 9 installation:                  |
|                                                   |
| d3dx9_24.dll (February 2005, 32 Bit)              |
| d3dx9_25.dll (April    2005, 32 Bit)              |
| d3dx9_26.dll (June     2005, 32 Bit)              |
| d3dx9_27.dll (August   2005, 32 Bit)              |
| d3dx9_28.dll (December 2005, 32 Bit)              |
| d3dx9_29.dll (February 2006, 32 Bit)              |
| d3dx9_30.dll (April    2006, 32 Bit)              |
| d3dx9_31.dll (October  2006, 32 Bit)              |
| d3dx9_32.dll (December 2006, 32 Bit)              |
| d3dx9_33.dll (April    2007, 32 Bit)              |
| d3dx9_34.dll (June     2007, 32 Bit)              |
| d3dx9_35.dll (August   2007, 32 Bit)              |
|                                                   |
|---------------------------------------------------|
|   Matthias Langer aka. T3L (t3l@threelights.de)   |
|---------------------------------------------------|

2007-09-22 by T3L